CREATE DATABASE  IF NOT EXISTS `proyectocrm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `proyectocrm`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: proyectocrm
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sucursales`
--

DROP TABLE IF EXISTS `sucursales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sucursales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `codigo_postal` varchar(255) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `horario_apertura` time DEFAULT NULL,
  `horario_cierre` time DEFAULT NULL,
  `gerente` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursales`
--

LOCK TABLES `sucursales` WRITE;
/*!40000 ALTER TABLE `sucursales` DISABLE KEYS */;
INSERT INTO `sucursales` VALUES (1,'Sucursal ville','Port Darrick','Vermont','30117','54172 Nayeli Port\nLake Marilyne, OK 56672-3434','1-714-950-0462','ozella49@windler.com','08:00:00','18:00:00','Retta Johnson',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(2,'Sucursal fort','Lake Parisland','New York','90193-7090','1645 Murazik Station Suite 395\nReynoldshaven, TX 47338-7574','1-231-940-5381','trantow.freeda@wisoky.com','08:00:00','18:00:00','Dr. Verla Mertz',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(3,'Sucursal land','Thompsonburgh','Wyoming','67014','610 Darius Oval\nNorth Arthur, VA 59548-5442','470-322-0568','markus.ritchie@rogahn.net','08:00:00','18:00:00','Glen Jacobi PhD',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(4,'Sucursal side','Gabriellaberg','Wisconsin','13004','35324 Kemmer Course\nGutkowskiberg, WV 51321-3989','+1-801-535-5415','dhoppe@ortiz.com','08:00:00','18:00:00','Miss Queen Kertzmann',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(5,'Sucursal berg','Larkinview','Idaho','52886','143 DuBuque Spur Apt. 347\nNorth Nakiachester, CO 55305-4332','+14079828236','maia25@runte.info','08:00:00','18:00:00','Sylvester Ritchie Sr.',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(6,'Sucursal burgh','Lake Winfieldside','Utah','48765-2132','13631 Dell Valleys Apt. 106\nSchusterton, ID 95706','484-589-4639','madison.kuhic@sporer.com','08:00:00','18:00:00','Mrs. Maia Corwin II',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(7,'Sucursal ton','Tressiebury','Mississippi','48335-4403','308 Bashirian Lakes Suite 335\nBoehmville, DC 12039','+1-484-970-0858','kankunding@smitham.net','08:00:00','18:00:00','Chance Jacobi',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49'),(8,'Sucursal stad','Owenview','New Hampshire','92435','362 Larson Street\nMayerstad, FL 71197','+1-989-669-0059','akeem.ledner@effertz.net','08:00:00','18:00:00','Carmel Harris',NULL,'2026-02-02 14:10:49','2026-02-02 14:10:49');
/*!40000 ALTER TABLE `sucursales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 20:14:50

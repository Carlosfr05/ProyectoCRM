CREATE DATABASE  IF NOT EXISTS `proyectocrm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `proyectocrm`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: proyectocrm
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `puesto` varchar(255) DEFAULT NULL,
  `salario` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fecha_contratacion` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,'Burley Pacocha','davis.baylee@example.net','808.809.2830','7819 Huel Island Suite 394\nNew Orpha, FL 42196','Vendedor',1181.62,'1990-07-08',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(2,'Prof. Velda Jast','ankunding.jasmin@example.org','828.451.5844','216 Norene Trail\nNew Kathleen, SC 18610','Desarrollador',4552.94,'1996-12-25',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(3,'Hulda Padberg','gutmann.terence@example.net','+1.720.844.5014','39492 Barton Cliffs\nShemarville, IA 55715-4312','Administrador',1290.54,'2024-01-09',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(4,'Demarco Prohaska','goodwin.gennaro@example.net','336.254.8694','49859 Harber Plain Apt. 691\nLake Gabebury, SC 27045','Vendedor',2488.17,'1981-12-06',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(5,'Declan Hessel','gcassin@example.com','678.429.9562','76862 Tromp Well\nLake Jany, NJ 78870-4465','Gerente',3116.95,'1986-10-27',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(6,'Elroy Kozey I','bdach@example.net','(240) 319-8586','87043 Brekke Roads\nCruickshankland, NV 26295-5691','Vendedor',4429.95,'2012-12-11',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(7,'Guy DuBuque','okeefe.kayleigh@example.org','+1.564.600.6134','1622 Jaida Glens Suite 310\nNorth Tobin, LA 07216-5517','Gerente',3837.74,'2024-10-06',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(8,'Ms. Mozelle Hills DDS','josefina86@example.org','+1-463-439-0492','2481 Hammes Burgs\nAlvahfort, OK 26774-8294','Soporte',1058.17,'1999-06-29',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(9,'Dr. Vince DuBuque Jr.','tzulauf@example.com','+1-323-612-5752','17116 Roob Plains Apt. 508\nWest Chyna, NH 27297','Vendedor',5606.05,'1984-12-07',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(10,'Miss Santina Bosco MD','qratke@example.net','1-319-226-9420','2754 Rowe Pass Apt. 789\nRosinaland, PA 73933-3322','Gerente',3247.95,'1997-10-30',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(11,'Kenna Hilpert','luettgen.ressie@example.net','+1 (213) 396-9407','87280 Cora Brook\nOttiliestad, NH 99534','Administrador',4178.43,'1989-03-03',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26'),(12,'Francesca Ernser','ugleason@example.com','+1 (559) 401-8442','5462 Marcus Motorway\nUrielside, ND 99943-7976','Desarrollador',3238.66,'2002-09-22',NULL,'2026-02-02 14:04:26','2026-02-02 14:04:26');
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 20:14:50

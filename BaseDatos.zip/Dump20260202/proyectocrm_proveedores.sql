CREATE DATABASE  IF NOT EXISTS `proyectocrm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `proyectocrm`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: proyectocrm
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `empresa` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Kessler, Cremin and Mayer','ledner.marques@roob.org','757-688-9350','840 Bryana Valleys\nEast Aureliaview, OH 72899-1183','Haag, Romaguera and O\'Hara',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(2,'Bergnaum and Sons','dmarks@carter.com','+16125542940','533 Bode Burgs\nPort Lilyanshire, NH 61778','Hirthe, Little and Johnson',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(3,'Casper-Wilderman','candace.bode@kunde.com','+1.423.402.9982','1091 Keebler Centers Apt. 251\nPort Oleta, DC 31672','Hettinger, Bashirian and Gulgowski',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(4,'Lowe-Emard','presley19@orn.biz','+1 (458) 391-9899','875 Robbie Passage Suite 791\nRempelshire, NM 57545-7764','Ernser Group',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(5,'Hansen Inc','bella65@cummerata.biz','856-539-4049','51330 Batz Alley Suite 833\nSchadenchester, AZ 51876-7323','Yundt PLC',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(6,'Kerluke Ltd','vruecker@oconnell.org','+1.219.726.0949','3724 Sarai Viaduct Suite 801\nMaggioborough, CO 03341-3900','Beatty-Pfannerstill',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(7,'Zieme-Baumbach','ocie48@fritsch.com','+12706358759','443 Ward Street\nLondonfort, TN 54880-9887','Cummings Inc',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(8,'Hickle-Wisoky','ollie.considine@west.com','725-431-4088','6842 Laura Springs Apt. 708\nWest Elody, CT 01024-9781','Conn-Brekke',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(9,'Pagac-Yundt','rocio.schmitt@hilpert.org','754-541-3357','985 Arlene Parkway Suite 262\nHagenesburgh, WV 33588','Adams, Baumbach and Murazik',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(10,'Reichert, Lemke and Kreiger','nkessler@gutmann.com','(210) 379-0082','77330 Kessler Alley Suite 823\nSouth Jamison, WI 02549','Simonis Ltd',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(11,'Pfeffer, Cormier and Dicki','smith.verla@stamm.com','(857) 455-8633','460 Batz Station\nLake Danefort, CA 89054','Metz LLC',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57'),(12,'Cormier, Bechtelar and Nader','nettie.robel@conn.org','+1.470.819.1272','31173 Bernier Passage\nLittlebury, VT 61853','Larkin-Runolfsson',NULL,'2026-02-02 13:43:57','2026-02-02 13:43:57');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 20:14:50

CREATE DATABASE  IF NOT EXISTS `proyectocrm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `proyectocrm`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: proyectocrm
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 0,
  `sku` varchar(255) NOT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `productos_sku_unique` (`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'aliquam reprehenderit molestias','Pariatur quia ipsa quasi veritatis. Sit consequatur maxime quam harum itaque fugit. Esse placeat sed est.',28.52,95,'50079056','Alimentos',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(2,'consectetur illum deserunt','Neque modi delectus et corporis necessitatibus. Officia veniam quo laborum minus consequatur nam exercitationem.',59.27,52,'96398548','Electrónica',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(3,'veritatis qui repellat','Fuga ut molestiae itaque aperiam qui. Magnam quo sint tempora facere repellendus. Perferendis aut minus pariatur quam maxime voluptatum et.',501.21,66,'46063847','Hogar',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(4,'illo modi neque','Ut libero adipisci occaecati itaque iusto ex. Expedita reiciendis necessitatibus ullam sunt occaecati error nemo. Optio beatae commodi excepturi nisi ex ea dolorem. Saepe amet omnis laborum aspernatur laudantium rerum fugiat qui. Recusandae fugiat vitae error qui porro.',715.50,91,'86061544','Libros',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(5,'incidunt eum fugit','Repellendus sint porro similique enim hic voluptate ut. Possimus dignissimos consequuntur recusandae id est. Incidunt est officiis odio dolor est voluptatem. Voluptatum libero ut laudantium nobis autem voluptatem cupiditate.',282.63,85,'82420192','Ropa',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(6,'facilis iusto facilis','Sequi error eos ipsa qui non dolorem occaecati. Quo et nemo quasi deserunt architecto. Qui maiores et et voluptatem.',634.60,21,'39771292','Deportes',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(7,'a sed amet','Et recusandae iusto nisi atque voluptatem. Repudiandae consectetur voluptate recusandae. Eius doloremque quidem quia quibusdam tenetur explicabo officia. Totam magnam qui quidem odit voluptatem et qui.',662.56,92,'96804131','Ropa',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(8,'aut et id','Architecto assumenda dolores dicta ut facilis. Asperiores fugit optio explicabo quo. Consequatur possimus modi minus unde at eum. Aut sequi ad voluptatem repellendus dolores consequatur officia.',725.14,65,'38658983','Electrónica',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(9,'enim dolor tempora','Ratione natus incidunt fuga rerum blanditiis molestiae veritatis. Quia ut rem unde beatae consectetur quis quae. Libero qui officiis omnis sed. Optio aut non qui placeat a minima exercitationem.',24.91,3,'40930091','Alimentos',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(10,'quisquam dolor laudantium','Distinctio voluptatem nostrum aut non nisi. Culpa velit tempora nobis praesentium dolorem nemo.',795.52,97,'02548579','Electrónica',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(11,'reprehenderit voluptatem occaecati','Quaerat saepe dolorem occaecati deserunt. Officia animi perferendis est dignissimos id officia quia. Eos sit repudiandae voluptatibus molestiae assumenda animi ratione id.',811.74,51,'47476936','Electrónica',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(12,'eum dolorem nihil','Aut aspernatur porro eum molestiae est. Aut eius deserunt hic soluta ducimus. Non error maxime beatae odit esse sint consequatur. Non itaque quaerat tenetur est eligendi mollitia et.',355.76,41,'10838372','Ropa',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(13,'rerum aut sunt','Saepe ut quibusdam blanditiis excepturi vel quod. Facere minima repudiandae ipsam nihil ipsa et vitae. Id debitis perspiciatis in adipisci placeat rem. Quisquam incidunt omnis vero. Tempora eius perspiciatis est quod.',327.85,32,'93190268','Libros',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(14,'earum quam error','Atque dolor labore voluptas excepturi animi omnis delectus. Delectus iste ut et voluptatem est. In et maiores et minus est eos et.',35.03,76,'51523428','Ropa',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46'),(15,'nemo odio provident','Aut aut cumque quibusdam eum voluptas. Reiciendis vel et illo sint et. Et tenetur eius distinctio aut ut eligendi.',766.99,3,'27410561','Ropa',NULL,'2026-02-02 13:26:46','2026-02-02 13:26:46');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 20:14:50
